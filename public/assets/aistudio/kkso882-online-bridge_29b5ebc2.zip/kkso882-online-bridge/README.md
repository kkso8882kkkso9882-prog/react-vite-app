# KKSO882 Online Bridge

A small FastAPI service hosted on Render. It provides an authenticated, allowlisted outbound HTTPS request endpoint so trusted clients can reach APIs through this server.

## What it does

- `GET /health` health check
- `GET /` service information
- `POST /v1/request` makes an outbound HTTPS request to an explicitly allowlisted hostname
- API-key authentication using `X-API-Key`
- Redirects disabled, bounded timeouts, request/response size limits, and rejection of non-public DNS results

This is **not** an unrestricted public proxy. Only exact hostnames listed in `BRIDGE_ALLOWED_HOSTS` can be contacted.

## Deploy to Render

1. Upload this ZIP's contents to a new GitHub repository named `kkso882-online-bridge` (extract the ZIP first; do not upload the ZIP as a single file).
2. In Render, choose **New → Blueprint** and connect that repository.
3. Review the Blueprint plan and apply it.
4. In the service environment settings, set `BRIDGE_ALLOWED_HOSTS` to the exact API hostnames you trust, separated by commas. Example: `api.example.com,api.github.com`.
5. Render generates `BRIDGE_API_KEY` from `generateValue: true`. Keep it secret.

The included Blueprint uses Render's `free` plan. Availability and limits depend on Render's current plan rules.

## Test

After deployment:

```bash
curl https://YOUR-SERVICE.onrender.com/health
```

Example authenticated request:

```bash
curl -X POST https://YOUR-SERVICE.onrender.com/v1/request \
  -H 'Content-Type: application/json' \
  -H 'X-API-Key: YOUR_BRIDGE_API_KEY' \
  -d '{
    "url": "https://api.example.com/status",
    "method": "GET"
  }'
```

The target hostname must be included in `BRIDGE_ALLOWED_HOSTS`.

## Request format

```json
{
  "url": "https://api.example.com/endpoint",
  "method": "GET",
  "headers": {
    "Accept": "application/json"
  },
  "params": {
    "page": "1"
  },
  "json": null,
  "body": null
}
```

Allowed methods: `GET`, `POST`, `PUT`, `PATCH`, `DELETE`, `HEAD`.

Use either `json` or `body` for a request payload. Do not put secrets in URLs or log them.

## Local run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Set BRIDGE_API_KEY and BRIDGE_ALLOWED_HOSTS in .env
uvicorn app.main:app --reload
```

## Security notes

- Never commit `.env` or expose `BRIDGE_API_KEY`.
- Allowlist only APIs you control or are authorized to access.
- Do not use this as an open proxy.
- DNS validation is a defense-in-depth check; for high-assurance deployments, use network-level egress controls as well.
- ChatGPT cannot automatically call an arbitrary Render URL just because it is online. A connector or tool integration must be configured to invoke this API.
