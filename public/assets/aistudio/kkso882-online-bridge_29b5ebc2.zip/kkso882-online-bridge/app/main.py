from __future__ import annotations

import ipaddress
import os
import secrets
import socket
from typing import Any
from urllib.parse import urlsplit

import httpx
from fastapi import Depends, FastAPI, Header, HTTPException, Request
from pydantic import BaseModel, Field, HttpUrl

APP_NAME = "KKSO882 Online Bridge"
API_KEY = os.getenv("BRIDGE_API_KEY", "")
ALLOWED_HOSTS = {
    item.strip().lower().rstrip(".")
    for item in os.getenv("BRIDGE_ALLOWED_HOSTS", "").split(",")
    if item.strip()
}
MAX_BODY_BYTES = int(os.getenv("BRIDGE_MAX_BODY_BYTES", "1048576"))
TIMEOUT_SECONDS = float(os.getenv("BRIDGE_TIMEOUT_SECONDS", "15"))

app = FastAPI(
    title=APP_NAME,
    version="1.0.0",
    description="Authenticated outbound HTTP bridge with host allowlisting.",
)


class RequestPayload(BaseModel):
    url: HttpUrl
    method: str = Field(default="GET", pattern="^(GET|POST|PUT|PATCH|DELETE|HEAD)$")
    headers: dict[str, str] = Field(default_factory=dict)
    params: dict[str, str] = Field(default_factory=dict)
    json: Any | None = None
    body: str | None = None


def require_api_key(x_api_key: str | None = Header(default=None)) -> None:
    if not API_KEY:
        raise HTTPException(status_code=503, detail="Server is not configured: BRIDGE_API_KEY is missing.")
    if not x_api_key or not secrets.compare_digest(x_api_key, API_KEY):
        raise HTTPException(status_code=401, detail="Invalid API key.")


def validate_target(raw_url: str) -> str:
    parsed = urlsplit(raw_url)
    if parsed.scheme != "https":
        raise HTTPException(status_code=400, detail="Only HTTPS targets are allowed.")
    if not parsed.hostname or parsed.username or parsed.password:
        raise HTTPException(status_code=400, detail="Invalid target URL.")
    host = parsed.hostname.lower().rstrip(".")
    if not ALLOWED_HOSTS or host not in ALLOWED_HOSTS:
        raise HTTPException(status_code=403, detail="Target host is not in BRIDGE_ALLOWED_HOSTS.")
    try:
        addresses = socket.getaddrinfo(host, parsed.port or 443, type=socket.SOCK_STREAM)
    except socket.gaierror:
        raise HTTPException(status_code=400, detail="Target hostname could not be resolved.")
    if not addresses:
        raise HTTPException(status_code=400, detail="Target hostname has no addresses.")
    for item in addresses:
        address = ipaddress.ip_address(item[4][0])
        if not address.is_global:
            raise HTTPException(status_code=403, detail="Target resolves to a non-public IP address.")
    return host


@app.get("/")
async def root():
    return {"name": APP_NAME, "status": "online", "docs": "/docs"}


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.post("/v1/request", dependencies=[Depends(require_api_key)])
async def proxy_request(payload: RequestPayload, request: Request):
    url = str(payload.url)
    validate_target(url)

    forbidden_headers = {"host", "content-length", "connection", "transfer-encoding"}
    outgoing_headers = {
        key: value for key, value in payload.headers.items()
        if key.lower() not in forbidden_headers
    }
    body_bytes = payload.body.encode("utf-8") if payload.body is not None else None
    if body_bytes is not None and len(body_bytes) > MAX_BODY_BYTES:
        raise HTTPException(status_code=413, detail="Request body is too large.")

    try:
        async with httpx.AsyncClient(
            timeout=TIMEOUT_SECONDS,
            follow_redirects=False,
            verify=True,
            trust_env=False,
        ) as client:
            response = await client.request(
                method=payload.method,
                url=url,
                headers=outgoing_headers,
                params=payload.params,
                json=payload.json,
                content=body_bytes,
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Upstream request timed out.")
    except httpx.RequestError:
        raise HTTPException(status_code=502, detail="Could not reach upstream server.")

    content = response.content
    if len(content) > MAX_BODY_BYTES:
        raise HTTPException(status_code=502, detail="Upstream response is too large.")

    content_type = response.headers.get("content-type", "")
    try:
        data: Any = response.json() if "json" in content_type.lower() else response.text
    except ValueError:
        data = response.text

    safe_response_headers = {
        key: value for key, value in response.headers.items()
        if key.lower() in {"content-type", "cache-control", "etag", "last-modified"}
    }
    return {
        "status_code": response.status_code,
        "headers": safe_response_headers,
        "data": data,
    }
